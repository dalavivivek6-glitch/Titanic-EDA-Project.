"""
Titanic Exploratory Data Analysis (EDA)
Run: python titanic_eda.py
Place Kaggle's train.csv in the same directory as this file.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


DATA_PATH = Path(__file__).parent / "train.csv"


def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            "train.csv was not found. Download the Kaggle Titanic training "
            "dataset and place train.csv beside titanic_eda.py."
        )

    raw_df = pd.read_csv(DATA_PATH)
    df = raw_df.copy()

    print("\\n=== First five rows ===")
    print(df.head())

    print("\\n=== Dataset information ===")
    df.info()

    print("\\n=== Statistical summary ===")
    print(df.describe(include="all"))

    print("\\n=== Missing values before cleaning ===")
    print(df.isnull().sum())

    # Missing-value visualization (before cleaning)
    plt.figure(figsize=(10, 5))
    sns.heatmap(df.isnull(), cbar=False, yticklabels=False)
    plt.title("Missing Values in Titanic Dataset")
    plt.tight_layout()
    plt.show()

    # Clean selected columns
    if "Age" in df.columns:
        df["Age"] = df["Age"].fillna(df["Age"].median())

    if "Fare" in df.columns:
        df["Fare"] = df["Fare"].fillna(df["Fare"].median())

    if "Embarked" in df.columns and not df["Embarked"].mode().empty:
        df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])

    # Cabin is very sparse in the standard training dataset.
    if "Cabin" in df.columns:
        df = df.drop(columns=["Cabin"])

    print("\\n=== Duplicate rows ===")
    print(df.duplicated().sum())
    df = df.drop_duplicates()

    print("\\n=== Missing values after cleaning ===")
    print(df.isnull().sum())

    # Grouping and aggregation
    if {"Sex", "Survived"}.issubset(df.columns):
        print("\\n=== Survival rate by gender ===")
        print(df.groupby("Sex")["Survived"].mean())

    if {"Pclass", "Survived"}.issubset(df.columns):
        print("\\n=== Survival rate by passenger class ===")
        print(df.groupby("Pclass")["Survived"].mean())

    if {"Pclass", "Age"}.issubset(df.columns):
        print("\\n=== Average age by passenger class ===")
        print(df.groupby("Pclass")["Age"].mean())

    if {"Sex", "PassengerId"}.issubset(df.columns):
        print("\\n=== Passenger count by gender ===")
        print(df.groupby("Sex")["PassengerId"].count())

    # Visualizations
    if "Survived" in df.columns:
        plt.figure(figsize=(6, 4))
        sns.countplot(data=df, x="Survived")
        plt.title("Titanic Survival Count (0 = No, 1 = Yes)")
        plt.tight_layout()
        plt.show()

    if {"Sex", "Survived"}.issubset(df.columns):
        plt.figure(figsize=(7, 4))
        sns.countplot(data=df, x="Sex", hue="Survived")
        plt.title("Survival by Gender")
        plt.tight_layout()
        plt.show()

    if {"Pclass", "Survived"}.issubset(df.columns):
        plt.figure(figsize=(7, 4))
        sns.countplot(data=df, x="Pclass", hue="Survived")
        plt.title("Survival by Passenger Class")
        plt.tight_layout()
        plt.show()

    if "Age" in df.columns:
        plt.figure(figsize=(8, 5))
        sns.histplot(data=df, x="Age", bins=20, kde=True)
        plt.title("Age Distribution of Passengers")
        plt.tight_layout()
        plt.show()

    numeric_df = df.select_dtypes(include=np.number)
    if not numeric_df.empty:
        plt.figure(figsize=(10, 6))
        sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm", fmt=".2f")
        plt.title("Correlation Heatmap")
        plt.tight_layout()
        plt.show()

    print("\\n=== Final dataset shape ===")
    print(df.shape)


if __name__ == "__main__":
    main()
