# Titanic Exploratory Data Analysis (EDA)

A beginner-friendly Python project that explores the Kaggle Titanic dataset using Pandas, NumPy, Matplotlib, and Seaborn.

## Project objectives

- Load and inspect the Titanic dataset.
- Explore rows, columns, data types, and summary statistics.
- Identify and handle missing values.
- Check for duplicate records.
- Group and aggregate passenger data.
- Visualize survival patterns.
- Explore correlations between numeric variables.

## Dataset

This project uses the **Kaggle Titanic: Machine Learning from Disaster** training dataset (`train.csv`).

1. Download `train.csv` from [Kaggle Titanic](https://www.kaggle.com/competitions/titanic/data).
2. Place `train.csv` in the project root (the same folder as `titanic_eda.py`).

The dataset is not included in this repository. You may need to sign in to Kaggle and accept the competition rules before downloading it.

## Project structure

```text
titanic-eda-github/
├── README.md
├── titanic_eda.py
├── requirements.txt
├── .gitignore
└── train.csv                 # Add locally; do not commit unless you have permission
```

## Setup

```bash
git clone https://github.com/YOUR-USERNAME/titanic-eda.git
cd titanic-eda
python -m venv .venv
```

Activate the virtual environment:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS / Linux**
```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Run the project

```bash
python titanic_eda.py
```

The script prints dataset summaries and group-by results, then displays charts.

## Main analysis

- `head()`, `info()`, and `describe()` for initial inspection.
- Missing-value counts and a missingness heatmap.
- Median imputation for `Age` and `Fare`.
- Mode imputation for `Embarked`.
- Removal of the mostly-missing `Cabin` column.
- Duplicate-row check.
- Survival analysis by gender and passenger class.
- Age distribution and numeric correlation heatmap.

## Expected baseline facts

For the original Kaggle `train.csv` dataset (before cleaning):

- 891 rows and 12 columns
- 342 survivors and 549 non-survivors
- 177 missing values in `Age`
- 687 missing values in `Cabin`
- 2 missing values in `Embarked`

## Notes

- Missing-value treatment is a simple demonstration, not the only valid approach.
- The script preserves the original dataset in memory as `raw_df` and performs cleaning on a copy.
- Results may differ if you use a different Titanic dataset or a modified CSV.

## Author

Add your name, course, and institution here.
